# MavenZone
This project contains the class room/ lab practice for maven
